import Cocoa

var str = "Hello, playground"

print(str)

let name: String = "Rick"
let age: Int = 27
print(name)
print(age)

var bassPlay: String
var bassPlayerAge: Int

let bassPlayer = (name: "Rick", surname: "Astley", age: 27)
print("His name is \(bassPlayer.name) \(bassPlayer.surname)")
print("His age is \(bassPlayer.age)")

var band = ["Tadokoro","Rick Astley"]
band.count
print(band[1])
print(band[0])


let bands = band + ["Richard Milos","Van"]

var band1: [Int: String] = [1:"Rick",2:"Tadokoro"]
band1[1]
band1[2]
band1[3]

var i = 0
while i < 5 {
    print("Index \(i)")
    i += 1
}
func greet() -> String {
    return "Rick Astely"
}
print(greet())

let greet1 = {
    print("Hello World!")
}
func greet2(name: String){
    print("Hello, \(name)")
}
greet2(name:"Rick Astley")

let greet3 = { (name: String) in
    return "Hello, \(name)"
}
print(greet3("EeEe"))

struct Player{
    let name: String
    let surname: String
    let age: Int
    let instrument: String
    func fullname() -> String {
        return "\(name) \(surname)"
    }
}
let bassPlayee = Player(name: "Rick", surname: "Astley",age: 27,instrument: "bass")
print("Name is \(bassPlayee.name) \(bassPlayee.surname)")
print("Name is \(bassPlayee.fullname())")

enum Instrument: String {
    case Guitar = "guitar"
    case Bass = "bass"
    case Sitar = "sitar"
    case Drum = "drum"
    case Keyboard = "keyboard"
}
let instru: Instrument = .Drum
switch instru {
case .Guitar:
    print("Let's play guitar")
case .Bass:
    print("Let's play bass")
case .Drum:
    print("Let's play drum")
case .Sitar:
    print("Let's play sitar")
case .Keyboard:
    print("Let's play keyboard")
}

var error: NSError?

